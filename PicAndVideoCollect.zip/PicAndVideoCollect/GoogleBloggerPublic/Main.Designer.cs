﻿namespace GoogleBloggerPublic
{
    partial class Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.tcgb = new System.Windows.Forms.TabControl();
            this.tpJiemian = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnJiemianShow = new System.Windows.Forms.Button();
            this.btnJiemianHide = new System.Windows.Forms.Button();
            this.tbJiemainPassword = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.tpMail = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tbMailSendUrl = new System.Windows.Forms.TextBox();
            this.cbMailSendType = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbmailPort = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbmailPassword = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbmailUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbfromMailAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbtoMailAddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbsenderServerIp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tpPic = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.cbPicBackup = new System.Windows.Forms.CheckBox();
            this.cbPicWaterOpen = new System.Windows.Forms.CheckBox();
            this.cbPicCutOpen = new System.Windows.Forms.CheckBox();
            this.cbPicWaterPosition = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tbPicPositionEndY = new System.Windows.Forms.TextBox();
            this.tbPicPositionStartY = new System.Windows.Forms.TextBox();
            this.tbPicPositionEndX = new System.Windows.Forms.TextBox();
            this.tbPicWaterText = new System.Windows.Forms.TextBox();
            this.tbPicPositionStartX = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnVerity = new System.Windows.Forms.Button();
            this.btnCompant = new System.Windows.Forms.Button();
            this.tbSharedSecret = new System.Windows.Forms.TextBox();
            this.tbOAuthCode = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tbApiKey = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tpPublic = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbPublicPicType = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cbPublicType = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.tbPublicPassword = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tbPublicNum = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tbPublicNextTime = new System.Windows.Forms.TextBox();
            this.lbPublicNextNum = new System.Windows.Forms.Label();
            this.tbPublicTimes = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tpXmlRpc = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tbXmlRpcPassword = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.tbXmlRpcUsername = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.tbXmlRpcUrl = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.tpCollect = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnChonse = new System.Windows.Forms.Button();
            this.tbPicPath = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbGroupNum = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbPageNum = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbPageList = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tpTrans = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.cbTran_open = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tbTran_to = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbTran_from = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tbTran_key = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tbtran_appid = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tpTimer = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cbTimerLog = new System.Windows.Forms.CheckBox();
            this.cbTimerOpen = new System.Windows.Forms.CheckBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.dtpTimerStop = new System.Windows.Forms.DateTimePicker();
            this.dtpTimerStart = new System.Windows.Forms.DateTimePicker();
            this.tpLog = new System.Windows.Forms.TabPage();
            this.lbLogList = new System.Windows.Forms.ListBox();
            this.label46 = new System.Windows.Forms.Label();
            this.tbXmlPRCCat = new System.Windows.Forms.TextBox();
            this.tcgb.SuspendLayout();
            this.tpJiemian.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tpMail.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tpPic.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tpPublic.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tpXmlRpc.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tpCollect.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tpTrans.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tpTimer.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tpLog.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcgb
            // 
            this.tcgb.Controls.Add(this.tpJiemian);
            this.tcgb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcgb.Location = new System.Drawing.Point(0, 0);
            this.tcgb.Margin = new System.Windows.Forms.Padding(10);
            this.tcgb.Name = "tcgb";
            this.tcgb.SelectedIndex = 0;
            this.tcgb.Size = new System.Drawing.Size(491, 385);
            this.tcgb.TabIndex = 0;
            // 
            // tpJiemian
            // 
            this.tpJiemian.Controls.Add(this.groupBox9);
            this.tpJiemian.Location = new System.Drawing.Point(4, 22);
            this.tpJiemian.Name = "tpJiemian";
            this.tpJiemian.Size = new System.Drawing.Size(483, 359);
            this.tpJiemian.TabIndex = 7;
            this.tpJiemian.Text = "界面";
            this.tpJiemian.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnJiemianShow);
            this.groupBox9.Controls.Add(this.btnJiemianHide);
            this.groupBox9.Controls.Add(this.tbJiemainPassword);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(0, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(483, 359);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "界面设置";
            // 
            // btnJiemianShow
            // 
            this.btnJiemianShow.Location = new System.Drawing.Point(281, 68);
            this.btnJiemianShow.Name = "btnJiemianShow";
            this.btnJiemianShow.Size = new System.Drawing.Size(75, 23);
            this.btnJiemianShow.TabIndex = 4;
            this.btnJiemianShow.Text = "显示";
            this.btnJiemianShow.UseVisualStyleBackColor = true;
            this.btnJiemianShow.Click += new System.EventHandler(this.btnJiemianShow_Click);
            // 
            // btnJiemianHide
            // 
            this.btnJiemianHide.Enabled = false;
            this.btnJiemianHide.Location = new System.Drawing.Point(375, 68);
            this.btnJiemianHide.Name = "btnJiemianHide";
            this.btnJiemianHide.Size = new System.Drawing.Size(75, 23);
            this.btnJiemianHide.TabIndex = 4;
            this.btnJiemianHide.Text = "隐藏";
            this.btnJiemianHide.UseVisualStyleBackColor = true;
            this.btnJiemianHide.Click += new System.EventHandler(this.btnJiemianHide_Click);
            // 
            // tbJiemainPassword
            // 
            this.tbJiemainPassword.Location = new System.Drawing.Point(131, 30);
            this.tbJiemainPassword.Name = "tbJiemainPassword";
            this.tbJiemainPassword.PasswordChar = '*';
            this.tbJiemainPassword.Size = new System.Drawing.Size(320, 21);
            this.tbJiemainPassword.TabIndex = 3;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(20, 34);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(59, 12);
            this.label37.TabIndex = 2;
            this.label37.Text = "显示密码:";
            // 
            // tpMail
            // 
            this.tpMail.Controls.Add(this.groupBox10);
            this.tpMail.Controls.Add(this.groupBox1);
            this.tpMail.Location = new System.Drawing.Point(4, 22);
            this.tpMail.Name = "tpMail";
            this.tpMail.Padding = new System.Windows.Forms.Padding(3);
            this.tpMail.Size = new System.Drawing.Size(483, 359);
            this.tpMail.TabIndex = 0;
            this.tpMail.Text = "邮件";
            this.tpMail.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.tbMailSendUrl);
            this.groupBox10.Controls.Add(this.cbMailSendType);
            this.groupBox10.Controls.Add(this.label40);
            this.groupBox10.Controls.Add(this.label39);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox10.Location = new System.Drawing.Point(3, 260);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(477, 95);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "发送设置";
            // 
            // tbMailSendUrl
            // 
            this.tbMailSendUrl.Location = new System.Drawing.Point(135, 60);
            this.tbMailSendUrl.Name = "tbMailSendUrl";
            this.tbMailSendUrl.ReadOnly = true;
            this.tbMailSendUrl.Size = new System.Drawing.Size(320, 21);
            this.tbMailSendUrl.TabIndex = 1;
            this.tbMailSendUrl.Text = "http://";
            // 
            // cbMailSendType
            // 
            this.cbMailSendType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMailSendType.FormattingEnabled = true;
            this.cbMailSendType.Items.AddRange(new object[] {
            "软件发送",
            "服务器转发"});
            this.cbMailSendType.Location = new System.Drawing.Point(135, 25);
            this.cbMailSendType.Name = "cbMailSendType";
            this.cbMailSendType.Size = new System.Drawing.Size(320, 20);
            this.cbMailSendType.TabIndex = 1;
            this.cbMailSendType.SelectedValueChanged += new System.EventHandler(this.cbMailSendType_SelectedValueChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(24, 63);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(71, 12);
            this.label40.TabIndex = 0;
            this.label40.Text = "服务器连接:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(24, 29);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(59, 12);
            this.label39.TabIndex = 0;
            this.label39.Text = "发送类型:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbmailPort);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbmailPassword);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbmailUsername);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbfromMailAddress);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbtoMailAddress);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbsenderServerIp);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(477, 257);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "邮件设置";
            // 
            // tbmailPort
            // 
            this.tbmailPort.Location = new System.Drawing.Point(135, 216);
            this.tbmailPort.Name = "tbmailPort";
            this.tbmailPort.Size = new System.Drawing.Size(320, 21);
            this.tbmailPort.TabIndex = 1;
            this.tbmailPort.Text = "587";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "mailPort:";
            // 
            // tbmailPassword
            // 
            this.tbmailPassword.Location = new System.Drawing.Point(135, 176);
            this.tbmailPassword.Name = "tbmailPassword";
            this.tbmailPassword.PasswordChar = '*';
            this.tbmailPassword.Size = new System.Drawing.Size(320, 21);
            this.tbmailPassword.TabIndex = 1;
            this.tbmailPassword.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "mailPassword:";
            // 
            // tbmailUsername
            // 
            this.tbmailUsername.Location = new System.Drawing.Point(135, 137);
            this.tbmailUsername.Name = "tbmailUsername";
            this.tbmailUsername.Size = new System.Drawing.Size(320, 21);
            this.tbmailUsername.TabIndex = 1;
            this.tbmailUsername.Text = "tiantianmeitu@hotmail.com";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "mailUsername:";
            // 
            // tbfromMailAddress
            // 
            this.tbfromMailAddress.Location = new System.Drawing.Point(135, 99);
            this.tbfromMailAddress.Name = "tbfromMailAddress";
            this.tbfromMailAddress.Size = new System.Drawing.Size(320, 21);
            this.tbfromMailAddress.TabIndex = 1;
            this.tbfromMailAddress.Text = "tiantianmeitu@hotmail.com";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "fromMailAddress:";
            // 
            // tbtoMailAddress
            // 
            this.tbtoMailAddress.Location = new System.Drawing.Point(135, 62);
            this.tbtoMailAddress.Name = "tbtoMailAddress";
            this.tbtoMailAddress.Size = new System.Drawing.Size(320, 21);
            this.tbtoMailAddress.TabIndex = 1;
            this.tbtoMailAddress.Text = "tiantianmeitu.send@blogger.com";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "toMailAddress:";
            // 
            // tbsenderServerIp
            // 
            this.tbsenderServerIp.Location = new System.Drawing.Point(135, 26);
            this.tbsenderServerIp.Name = "tbsenderServerIp";
            this.tbsenderServerIp.Size = new System.Drawing.Size(320, 21);
            this.tbsenderServerIp.TabIndex = 1;
            this.tbsenderServerIp.Text = "smtp-mail.outlook.com";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "senderServerIp:";
            // 
            // tpPic
            // 
            this.tpPic.Controls.Add(this.groupBox7);
            this.tpPic.Controls.Add(this.groupBox4);
            this.tpPic.Location = new System.Drawing.Point(4, 22);
            this.tpPic.Name = "tpPic";
            this.tpPic.Size = new System.Drawing.Size(483, 359);
            this.tpPic.TabIndex = 4;
            this.tpPic.Text = "图片";
            this.tpPic.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.cbPicBackup);
            this.groupBox7.Controls.Add(this.cbPicWaterOpen);
            this.groupBox7.Controls.Add(this.cbPicCutOpen);
            this.groupBox7.Controls.Add(this.cbPicWaterPosition);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label23);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.tbPicPositionEndY);
            this.groupBox7.Controls.Add(this.tbPicPositionStartY);
            this.groupBox7.Controls.Add(this.tbPicPositionEndX);
            this.groupBox7.Controls.Add(this.tbPicWaterText);
            this.groupBox7.Controls.Add(this.tbPicPositionStartX);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox7.Location = new System.Drawing.Point(0, 132);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(483, 191);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "图片处理";
            // 
            // cbPicBackup
            // 
            this.cbPicBackup.AutoSize = true;
            this.cbPicBackup.Location = new System.Drawing.Point(316, 161);
            this.cbPicBackup.Name = "cbPicBackup";
            this.cbPicBackup.Size = new System.Drawing.Size(15, 14);
            this.cbPicBackup.TabIndex = 4;
            this.cbPicBackup.UseVisualStyleBackColor = true;
            // 
            // cbPicWaterOpen
            // 
            this.cbPicWaterOpen.AutoSize = true;
            this.cbPicWaterOpen.Location = new System.Drawing.Point(190, 161);
            this.cbPicWaterOpen.Name = "cbPicWaterOpen";
            this.cbPicWaterOpen.Size = new System.Drawing.Size(15, 14);
            this.cbPicWaterOpen.TabIndex = 4;
            this.cbPicWaterOpen.UseVisualStyleBackColor = true;
            // 
            // cbPicCutOpen
            // 
            this.cbPicCutOpen.AutoSize = true;
            this.cbPicCutOpen.Location = new System.Drawing.Point(75, 160);
            this.cbPicCutOpen.Name = "cbPicCutOpen";
            this.cbPicCutOpen.Size = new System.Drawing.Size(15, 14);
            this.cbPicCutOpen.TabIndex = 4;
            this.cbPicCutOpen.UseVisualStyleBackColor = true;
            // 
            // cbPicWaterPosition
            // 
            this.cbPicWaterPosition.FormattingEnabled = true;
            this.cbPicWaterPosition.Items.AddRange(new object[] {
            "TOP_LEFT",
            "TOP_RIGHT",
            "BOTTOM_RIGHT",
            "BOTTOM_LEFT"});
            this.cbPicWaterPosition.Location = new System.Drawing.Point(325, 125);
            this.cbPicWaterPosition.Name = "cbPicWaterPosition";
            this.cbPicWaterPosition.Size = new System.Drawing.Size(148, 20);
            this.cbPicWaterPosition.TabIndex = 3;
            this.cbPicWaterPosition.Text = "BOTTOM_RIGHT";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(364, 55);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 12);
            this.label26.TabIndex = 2;
            this.label26.Text = "结束Y:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(125, 59);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 12);
            this.label24.TabIndex = 2;
            this.label24.Text = "开始Y:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(249, 59);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 12);
            this.label25.TabIndex = 2;
            this.label25.Text = "结束X:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(260, 128);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 12);
            this.label29.TabIndex = 2;
            this.label29.Text = "水印位置:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 128);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 12);
            this.label28.TabIndex = 2;
            this.label28.Text = "水印内容:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 59);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "开始X:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(11, 98);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 12);
            this.label27.TabIndex = 0;
            this.label27.Text = "水印位置:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(234, 162);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(83, 12);
            this.label32.TabIndex = 0;
            this.label32.Text = "图片本地备份:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(125, 162);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(59, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "图片水印:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(10, 161);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 12);
            this.label30.TabIndex = 0;
            this.label30.Text = "图片剪切:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 30);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(59, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "剪切位置:";
            // 
            // tbPicPositionEndY
            // 
            this.tbPicPositionEndY.Location = new System.Drawing.Point(411, 54);
            this.tbPicPositionEndY.Name = "tbPicPositionEndY";
            this.tbPicPositionEndY.Size = new System.Drawing.Size(62, 21);
            this.tbPicPositionEndY.TabIndex = 1;
            this.tbPicPositionEndY.Text = "0";
            // 
            // tbPicPositionStartY
            // 
            this.tbPicPositionStartY.Location = new System.Drawing.Point(172, 54);
            this.tbPicPositionStartY.Name = "tbPicPositionStartY";
            this.tbPicPositionStartY.Size = new System.Drawing.Size(62, 21);
            this.tbPicPositionStartY.TabIndex = 1;
            this.tbPicPositionStartY.Text = "0";
            // 
            // tbPicPositionEndX
            // 
            this.tbPicPositionEndX.Location = new System.Drawing.Point(296, 54);
            this.tbPicPositionEndX.Name = "tbPicPositionEndX";
            this.tbPicPositionEndX.Size = new System.Drawing.Size(62, 21);
            this.tbPicPositionEndX.TabIndex = 1;
            this.tbPicPositionEndX.Text = "0";
            // 
            // tbPicWaterText
            // 
            this.tbPicWaterText.Location = new System.Drawing.Point(75, 125);
            this.tbPicWaterText.Name = "tbPicWaterText";
            this.tbPicWaterText.Size = new System.Drawing.Size(148, 21);
            this.tbPicWaterText.TabIndex = 1;
            this.tbPicWaterText.Text = "http://";
            // 
            // tbPicPositionStartX
            // 
            this.tbPicPositionStartX.Location = new System.Drawing.Point(57, 54);
            this.tbPicPositionStartX.Name = "tbPicPositionStartX";
            this.tbPicPositionStartX.Size = new System.Drawing.Size(62, 21);
            this.tbPicPositionStartX.TabIndex = 1;
            this.tbPicPositionStartX.Text = "0";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnVerity);
            this.groupBox4.Controls.Add(this.btnCompant);
            this.groupBox4.Controls.Add(this.tbSharedSecret);
            this.groupBox4.Controls.Add(this.tbOAuthCode);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.tbApiKey);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(483, 132);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Flickr设置";
            // 
            // btnVerity
            // 
            this.btnVerity.Enabled = false;
            this.btnVerity.Location = new System.Drawing.Point(299, 94);
            this.btnVerity.Name = "btnVerity";
            this.btnVerity.Size = new System.Drawing.Size(75, 23);
            this.btnVerity.TabIndex = 2;
            this.btnVerity.Text = "验证";
            this.btnVerity.UseVisualStyleBackColor = true;
            this.btnVerity.Click += new System.EventHandler(this.btnVerity_Click);
            // 
            // btnCompant
            // 
            this.btnCompant.Enabled = false;
            this.btnCompant.Location = new System.Drawing.Point(380, 94);
            this.btnCompant.Name = "btnCompant";
            this.btnCompant.Size = new System.Drawing.Size(75, 23);
            this.btnCompant.TabIndex = 2;
            this.btnCompant.Text = "完成";
            this.btnCompant.UseVisualStyleBackColor = true;
            this.btnCompant.Click += new System.EventHandler(this.btnCompant_Click);
            // 
            // tbSharedSecret
            // 
            this.tbSharedSecret.Location = new System.Drawing.Point(134, 59);
            this.tbSharedSecret.Name = "tbSharedSecret";
            this.tbSharedSecret.Size = new System.Drawing.Size(320, 21);
            this.tbSharedSecret.TabIndex = 1;
            this.tbSharedSecret.Text = "cab27126f984bcb5";
            // 
            // tbOAuthCode
            // 
            this.tbOAuthCode.Location = new System.Drawing.Point(135, 95);
            this.tbOAuthCode.Name = "tbOAuthCode";
            this.tbOAuthCode.Size = new System.Drawing.Size(158, 21);
            this.tbOAuthCode.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(24, 99);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "OAuth:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(23, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "SharedSecret：";
            // 
            // tbApiKey
            // 
            this.tbApiKey.Location = new System.Drawing.Point(134, 23);
            this.tbApiKey.Name = "tbApiKey";
            this.tbApiKey.Size = new System.Drawing.Size(320, 21);
            this.tbApiKey.TabIndex = 1;
            this.tbApiKey.Text = "1879c811b79c8cb322f3a756ee3dada4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "ApiKey：";
            // 
            // tpPublic
            // 
            this.tpPublic.Controls.Add(this.groupBox5);
            this.tpPublic.Controls.Add(this.groupBox3);
            this.tpPublic.Location = new System.Drawing.Point(4, 22);
            this.tpPublic.Name = "tpPublic";
            this.tpPublic.Size = new System.Drawing.Size(483, 359);
            this.tpPublic.TabIndex = 3;
            this.tpPublic.Text = "发布";
            this.tpPublic.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnStart);
            this.groupBox5.Controls.Add(this.btnStop);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox5.Location = new System.Drawing.Point(0, 251);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(483, 58);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "操作";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(286, 20);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 5;
            this.btnStart.Text = "开始";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(379, 20);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 4;
            this.btnStop.Text = "停止";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbPublicPicType);
            this.groupBox3.Controls.Add(this.label41);
            this.groupBox3.Controls.Add(this.cbPublicType);
            this.groupBox3.Controls.Add(this.label42);
            this.groupBox3.Controls.Add(this.tbPublicPassword);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.tbPublicNum);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.tbPublicNextTime);
            this.groupBox3.Controls.Add(this.lbPublicNextNum);
            this.groupBox3.Controls.Add(this.tbPublicTimes);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(483, 251);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "发布设置";
            // 
            // cbPublicPicType
            // 
            this.cbPublicPicType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPublicPicType.FormattingEnabled = true;
            this.cbPublicPicType.Items.AddRange(new object[] {
            "Flickr",
            "XMLRPC"});
            this.cbPublicPicType.Location = new System.Drawing.Point(137, 213);
            this.cbPublicPicType.Name = "cbPublicPicType";
            this.cbPublicPicType.Size = new System.Drawing.Size(320, 20);
            this.cbPublicPicType.TabIndex = 3;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(26, 217);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(83, 12);
            this.label41.TabIndex = 2;
            this.label41.Text = "图片上传类型:";
            // 
            // cbPublicType
            // 
            this.cbPublicType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPublicType.FormattingEnabled = true;
            this.cbPublicType.Items.AddRange(new object[] {
            "邮件发布",
            "XMLRPC发布"});
            this.cbPublicType.Location = new System.Drawing.Point(137, 175);
            this.cbPublicType.Name = "cbPublicType";
            this.cbPublicType.Size = new System.Drawing.Size(320, 20);
            this.cbPublicType.TabIndex = 3;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(26, 179);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(59, 12);
            this.label42.TabIndex = 2;
            this.label42.Text = "发布类型:";
            // 
            // tbPublicPassword
            // 
            this.tbPublicPassword.Location = new System.Drawing.Point(134, 137);
            this.tbPublicPassword.Name = "tbPublicPassword";
            this.tbPublicPassword.PasswordChar = '*';
            this.tbPublicPassword.Size = new System.Drawing.Size(320, 21);
            this.tbPublicPassword.TabIndex = 1;
            this.tbPublicPassword.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(23, 141);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(59, 12);
            this.label36.TabIndex = 0;
            this.label36.Text = "发布密码:";
            // 
            // tbPublicNum
            // 
            this.tbPublicNum.Location = new System.Drawing.Point(134, 100);
            this.tbPublicNum.Name = "tbPublicNum";
            this.tbPublicNum.Size = new System.Drawing.Size(320, 21);
            this.tbPublicNum.TabIndex = 1;
            this.tbPublicNum.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(23, 104);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "发布数目:";
            // 
            // tbPublicNextTime
            // 
            this.tbPublicNextTime.Location = new System.Drawing.Point(134, 64);
            this.tbPublicNextTime.Name = "tbPublicNextTime";
            this.tbPublicNextTime.Size = new System.Drawing.Size(320, 21);
            this.tbPublicNextTime.TabIndex = 1;
            this.tbPublicNextTime.Text = "0";
            // 
            // lbPublicNextNum
            // 
            this.lbPublicNextNum.AutoSize = true;
            this.lbPublicNextNum.Location = new System.Drawing.Point(23, 68);
            this.lbPublicNextNum.Name = "lbPublicNextNum";
            this.lbPublicNextNum.Size = new System.Drawing.Size(71, 12);
            this.lbPublicNextNum.TabIndex = 0;
            this.lbPublicNextNum.Text = "下一页频率:";
            // 
            // tbPublicTimes
            // 
            this.tbPublicTimes.Location = new System.Drawing.Point(134, 27);
            this.tbPublicTimes.Name = "tbPublicTimes";
            this.tbPublicTimes.Size = new System.Drawing.Size(320, 21);
            this.tbPublicTimes.TabIndex = 1;
            this.tbPublicTimes.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "发布频率:";
            // 
            // tpXmlRpc
            // 
            this.tpXmlRpc.Controls.Add(this.groupBox11);
            this.tpXmlRpc.Location = new System.Drawing.Point(4, 22);
            this.tpXmlRpc.Name = "tpXmlRpc";
            this.tpXmlRpc.Size = new System.Drawing.Size(483, 359);
            this.tpXmlRpc.TabIndex = 8;
            this.tpXmlRpc.Text = "XMLRPC";
            this.tpXmlRpc.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.tbXmlPRCCat);
            this.groupBox11.Controls.Add(this.label46);
            this.groupBox11.Controls.Add(this.tbXmlRpcPassword);
            this.groupBox11.Controls.Add(this.label45);
            this.groupBox11.Controls.Add(this.tbXmlRpcUsername);
            this.groupBox11.Controls.Add(this.label44);
            this.groupBox11.Controls.Add(this.tbXmlRpcUrl);
            this.groupBox11.Controls.Add(this.label43);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(0, 0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(483, 359);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "XMLRPC设置";
            // 
            // tbXmlRpcPassword
            // 
            this.tbXmlRpcPassword.Location = new System.Drawing.Point(137, 105);
            this.tbXmlRpcPassword.Name = "tbXmlRpcPassword";
            this.tbXmlRpcPassword.PasswordChar = '*';
            this.tbXmlRpcPassword.Size = new System.Drawing.Size(320, 21);
            this.tbXmlRpcPassword.TabIndex = 3;
            this.tbXmlRpcPassword.Text = "zlh900412yzl";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(26, 109);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 12);
            this.label45.TabIndex = 2;
            this.label45.Text = "密码:";
            // 
            // tbXmlRpcUsername
            // 
            this.tbXmlRpcUsername.Location = new System.Drawing.Point(137, 67);
            this.tbXmlRpcUsername.Name = "tbXmlRpcUsername";
            this.tbXmlRpcUsername.PasswordChar = '*';
            this.tbXmlRpcUsername.Size = new System.Drawing.Size(320, 21);
            this.tbXmlRpcUsername.TabIndex = 3;
            this.tbXmlRpcUsername.Text = "admin";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(26, 71);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(35, 12);
            this.label44.TabIndex = 2;
            this.label44.Text = "帐号:";
            // 
            // tbXmlRpcUrl
            // 
            this.tbXmlRpcUrl.Location = new System.Drawing.Point(137, 27);
            this.tbXmlRpcUrl.Name = "tbXmlRpcUrl";
            this.tbXmlRpcUrl.Size = new System.Drawing.Size(320, 21);
            this.tbXmlRpcUrl.TabIndex = 3;
            this.tbXmlRpcUrl.Text = "http://girl.picturehub.net/xmlrpc.php";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(26, 31);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(35, 12);
            this.label43.TabIndex = 2;
            this.label43.Text = "链接:";
            // 
            // tpCollect
            // 
            this.tpCollect.Controls.Add(this.groupBox2);
            this.tpCollect.Location = new System.Drawing.Point(4, 22);
            this.tpCollect.Name = "tpCollect";
            this.tpCollect.Size = new System.Drawing.Size(483, 323);
            this.tpCollect.TabIndex = 2;
            this.tpCollect.Text = "采集";
            this.tpCollect.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbType);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.btnChonse);
            this.groupBox2.Controls.Add(this.tbPicPath);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tbGroupNum);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.tbPageNum);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.tbPageList);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(483, 323);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "采集设置";
            // 
            // cbType
            // 
            this.cbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbType.FormattingEnabled = true;
            this.cbType.Items.AddRange(new object[] {
            "mm131",
            "8090mg",
            "gogorenti"});
            this.cbType.Location = new System.Drawing.Point(135, 180);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(319, 20);
            this.cbType.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(23, 184);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 12);
            this.label16.TabIndex = 3;
            this.label16.Text = "采集类型:";
            // 
            // btnChonse
            // 
            this.btnChonse.Location = new System.Drawing.Point(379, 139);
            this.btnChonse.Name = "btnChonse";
            this.btnChonse.Size = new System.Drawing.Size(75, 23);
            this.btnChonse.TabIndex = 2;
            this.btnChonse.Text = "选择";
            this.btnChonse.UseVisualStyleBackColor = true;
            this.btnChonse.Click += new System.EventHandler(this.btnChonse_Click);
            // 
            // tbPicPath
            // 
            this.tbPicPath.Location = new System.Drawing.Point(134, 140);
            this.tbPicPath.Name = "tbPicPath";
            this.tbPicPath.ReadOnly = true;
            this.tbPicPath.Size = new System.Drawing.Size(227, 21);
            this.tbPicPath.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 144);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "图片下载路径:";
            // 
            // tbGroupNum
            // 
            this.tbGroupNum.Location = new System.Drawing.Point(134, 105);
            this.tbGroupNum.Name = "tbGroupNum";
            this.tbGroupNum.Size = new System.Drawing.Size(320, 21);
            this.tbGroupNum.TabIndex = 1;
            this.tbGroupNum.Text = "1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(23, 109);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "分组:";
            // 
            // tbPageNum
            // 
            this.tbPageNum.Location = new System.Drawing.Point(135, 68);
            this.tbPageNum.Name = "tbPageNum";
            this.tbPageNum.Size = new System.Drawing.Size(320, 21);
            this.tbPageNum.TabIndex = 1;
            this.tbPageNum.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "页码:";
            // 
            // tbPageList
            // 
            this.tbPageList.Location = new System.Drawing.Point(135, 29);
            this.tbPageList.Name = "tbPageList";
            this.tbPageList.Size = new System.Drawing.Size(320, 21);
            this.tbPageList.TabIndex = 1;
            this.tbPageList.Text = "http://www.mm131.com/xinggan/list_6_***.html";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "采集列表页:";
            // 
            // tpTrans
            // 
            this.tpTrans.Controls.Add(this.groupBox6);
            this.tpTrans.Location = new System.Drawing.Point(4, 22);
            this.tpTrans.Name = "tpTrans";
            this.tpTrans.Size = new System.Drawing.Size(483, 323);
            this.tpTrans.TabIndex = 5;
            this.tpTrans.Text = "翻译";
            this.tpTrans.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.cbTran_open);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.tbTran_to);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.tbTran_from);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.tbTran_key);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.tbtran_appid);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(483, 323);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "翻译设置";
            // 
            // cbTran_open
            // 
            this.cbTran_open.AutoSize = true;
            this.cbTran_open.Location = new System.Drawing.Point(132, 189);
            this.cbTran_open.Name = "cbTran_open";
            this.cbTran_open.Size = new System.Drawing.Size(15, 14);
            this.cbTran_open.TabIndex = 4;
            this.cbTran_open.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(21, 189);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 12);
            this.label21.TabIndex = 2;
            this.label21.Text = "是否启用:";
            // 
            // tbTran_to
            // 
            this.tbTran_to.Location = new System.Drawing.Point(132, 143);
            this.tbTran_to.Name = "tbTran_to";
            this.tbTran_to.Size = new System.Drawing.Size(320, 21);
            this.tbTran_to.TabIndex = 3;
            this.tbTran_to.Text = "en";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(21, 147);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 12);
            this.label20.TabIndex = 2;
            this.label20.Text = "目的语言:";
            // 
            // tbTran_from
            // 
            this.tbTran_from.Location = new System.Drawing.Point(132, 106);
            this.tbTran_from.Name = "tbTran_from";
            this.tbTran_from.Size = new System.Drawing.Size(320, 21);
            this.tbTran_from.TabIndex = 3;
            this.tbTran_from.Text = "zh";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 110);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 12);
            this.label19.TabIndex = 2;
            this.label19.Text = "源语言:";
            // 
            // tbTran_key
            // 
            this.tbTran_key.Location = new System.Drawing.Point(132, 68);
            this.tbTran_key.Name = "tbTran_key";
            this.tbTran_key.Size = new System.Drawing.Size(320, 21);
            this.tbTran_key.TabIndex = 3;
            this.tbTran_key.Text = "S9kJtRbFMRQBN2hW0ceD";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(21, 72);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 2;
            this.label18.Text = "百度key:";
            // 
            // tbtran_appid
            // 
            this.tbtran_appid.Location = new System.Drawing.Point(132, 29);
            this.tbtran_appid.Name = "tbtran_appid";
            this.tbtran_appid.Size = new System.Drawing.Size(320, 21);
            this.tbtran_appid.TabIndex = 3;
            this.tbtran_appid.Text = "20160925000029248";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(21, 33);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 2;
            this.label17.Text = "百度appid:";
            // 
            // tpTimer
            // 
            this.tpTimer.Controls.Add(this.groupBox8);
            this.tpTimer.Location = new System.Drawing.Point(4, 22);
            this.tpTimer.Name = "tpTimer";
            this.tpTimer.Size = new System.Drawing.Size(483, 323);
            this.tpTimer.TabIndex = 6;
            this.tpTimer.Text = "定时";
            this.tpTimer.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cbTimerLog);
            this.groupBox8.Controls.Add(this.cbTimerOpen);
            this.groupBox8.Controls.Add(this.label38);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.label34);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Controls.Add(this.dtpTimerStop);
            this.groupBox8.Controls.Add(this.dtpTimerStart);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(483, 323);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "定时设置";
            // 
            // cbTimerLog
            // 
            this.cbTimerLog.AutoSize = true;
            this.cbTimerLog.Location = new System.Drawing.Point(176, 100);
            this.cbTimerLog.Name = "cbTimerLog";
            this.cbTimerLog.Size = new System.Drawing.Size(15, 14);
            this.cbTimerLog.TabIndex = 3;
            this.cbTimerLog.UseVisualStyleBackColor = true;
            // 
            // cbTimerOpen
            // 
            this.cbTimerOpen.AutoSize = true;
            this.cbTimerOpen.Location = new System.Drawing.Point(75, 100);
            this.cbTimerOpen.Name = "cbTimerOpen";
            this.cbTimerOpen.Size = new System.Drawing.Size(15, 14);
            this.cbTimerOpen.TabIndex = 3;
            this.cbTimerOpen.UseVisualStyleBackColor = true;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(111, 100);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(59, 12);
            this.label38.TabIndex = 2;
            this.label38.Text = "生成日志:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(10, 100);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(59, 12);
            this.label35.TabIndex = 2;
            this.label35.Text = "开启定时:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(8, 66);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(83, 12);
            this.label34.TabIndex = 1;
            this.label34.Text = "每天结束时间:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(8, 29);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(83, 12);
            this.label33.TabIndex = 1;
            this.label33.Text = "每天开始时间:";
            // 
            // dtpTimerStop
            // 
            this.dtpTimerStop.CustomFormat = "HH:mm";
            this.dtpTimerStop.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpTimerStop.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTimerStop.Location = new System.Drawing.Point(110, 62);
            this.dtpTimerStop.Name = "dtpTimerStop";
            this.dtpTimerStop.ShowUpDown = true;
            this.dtpTimerStop.Size = new System.Drawing.Size(365, 21);
            this.dtpTimerStop.TabIndex = 0;
            // 
            // dtpTimerStart
            // 
            this.dtpTimerStart.CustomFormat = "HH:mm";
            this.dtpTimerStart.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpTimerStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTimerStart.Location = new System.Drawing.Point(110, 25);
            this.dtpTimerStart.Name = "dtpTimerStart";
            this.dtpTimerStart.ShowUpDown = true;
            this.dtpTimerStart.Size = new System.Drawing.Size(365, 21);
            this.dtpTimerStart.TabIndex = 0;
            // 
            // tpLog
            // 
            this.tpLog.Controls.Add(this.lbLogList);
            this.tpLog.Location = new System.Drawing.Point(4, 22);
            this.tpLog.Name = "tpLog";
            this.tpLog.Padding = new System.Windows.Forms.Padding(3);
            this.tpLog.Size = new System.Drawing.Size(483, 323);
            this.tpLog.TabIndex = 1;
            this.tpLog.Text = "日志";
            this.tpLog.UseVisualStyleBackColor = true;
            // 
            // lbLogList
            // 
            this.lbLogList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbLogList.FormattingEnabled = true;
            this.lbLogList.ItemHeight = 12;
            this.lbLogList.Location = new System.Drawing.Point(3, 3);
            this.lbLogList.Name = "lbLogList";
            this.lbLogList.Size = new System.Drawing.Size(477, 317);
            this.lbLogList.TabIndex = 0;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(26, 146);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 12);
            this.label46.TabIndex = 2;
            this.label46.Text = "分类:";
            // 
            // tbXmlPRCCat
            // 
            this.tbXmlPRCCat.Location = new System.Drawing.Point(137, 142);
            this.tbXmlPRCCat.Name = "tbXmlPRCCat";
            this.tbXmlPRCCat.Size = new System.Drawing.Size(320, 21);
            this.tbXmlPRCCat.TabIndex = 3;
            this.tbXmlPRCCat.Text = "性感美女";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 385);
            this.Controls.Add(this.tcgb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Google Blogger Auto Public For Jhonse";
            this.Activated += new System.EventHandler(this.Main_Activated);
            this.Load += new System.EventHandler(this.Main_Load);
            this.Leave += new System.EventHandler(this.Main_Leave);
            this.tcgb.ResumeLayout(false);
            this.tpJiemian.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tpMail.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tpPic.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tpPublic.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tpXmlRpc.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tpCollect.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tpTrans.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tpTimer.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tpLog.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcgb;
        private System.Windows.Forms.TabPage tpMail;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbsenderServerIp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbmailPort;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbmailPassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbmailUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbfromMailAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbtoMailAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tpLog;
        private System.Windows.Forms.ListBox lbLogList;
        private System.Windows.Forms.TabPage tpCollect;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbType;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnChonse;
        private System.Windows.Forms.TextBox tbPicPath;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbGroupNum;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbPageNum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbPageList;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tpPic;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnVerity;
        private System.Windows.Forms.Button btnCompant;
        private System.Windows.Forms.TextBox tbSharedSecret;
        private System.Windows.Forms.TextBox tbOAuthCode;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbApiKey;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tpPublic;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbPublicNum;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbPublicNextTime;
        private System.Windows.Forms.Label lbPublicNextNum;
        private System.Windows.Forms.TextBox tbPublicTimes;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tpTrans;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox tbtran_appid;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbTran_key;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbTran_from;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox cbTran_open;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbTran_to;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbPicPositionEndY;
        private System.Windows.Forms.TextBox tbPicPositionStartY;
        private System.Windows.Forms.TextBox tbPicPositionEndX;
        private System.Windows.Forms.TextBox tbPicPositionStartX;
        private System.Windows.Forms.ComboBox cbPicWaterPosition;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tbPicWaterText;
        private System.Windows.Forms.CheckBox cbPicWaterOpen;
        private System.Windows.Forms.CheckBox cbPicCutOpen;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.CheckBox cbPicBackup;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TabPage tpTimer;
        private System.Windows.Forms.DateTimePicker dtpTimerStart;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker dtpTimerStop;
        private System.Windows.Forms.CheckBox cbTimerOpen;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox tbPublicPassword;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TabPage tpJiemian;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnJiemianShow;
        private System.Windows.Forms.Button btnJiemianHide;
        private System.Windows.Forms.TextBox tbJiemainPassword;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.CheckBox cbTimerLog;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ComboBox cbMailSendType;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox tbMailSendUrl;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox cbPublicType;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TabPage tpXmlRpc;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox tbXmlRpcPassword;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox tbXmlRpcUsername;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox tbXmlRpcUrl;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cbPublicPicType;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox tbXmlPRCCat;
        private System.Windows.Forms.Label label46;
    }
}

